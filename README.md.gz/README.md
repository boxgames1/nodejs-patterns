# Node JS Design Patterns

Highlights and code chunks

Quokka.js usage is advised to run code snippets in the IDE